from .dream import Dream

__version__ = '0.1.0'
__author__ = 'kinhosz'
__email__ = 'scruz.josecarlos@gmail.com'
