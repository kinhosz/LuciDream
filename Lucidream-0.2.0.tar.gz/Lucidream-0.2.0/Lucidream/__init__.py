from .dream import Dream

__version__ = '0.2.0'
__author__ = 'kinhosz'
__email__ = 'scruz.josecarlos@gmail.com'
