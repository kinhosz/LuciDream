from .languages import Languages
from .newGame import NewGame
from .play import Play
